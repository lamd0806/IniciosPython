"""
Fecha:18/06/2021
Nombre:Luz Andrea Martínez Díaz
"""

import funciones as f


#MENU GENERAL
"""
Creado por: Luz Andrea Martínez Díaz
Fecha: 21/06/2021
"""


# Opciones Generales
while True:
  print("\n")
  print('INVENTARIO')    
  print('1. Ingresar o actualizar Producto')
  print('2. Imprimir Inventario')
  print('3. Imprimir Inventario por categoria')
  print('4. Facturar Venta')
  print('5. Registrar Venta')
  print('6. Graficar Ventas')
  print('0. Salir del Programa')
  print("\n")
  opcion=input('Seleccione una opción: ')
  
  if opcion=='1':
    print("\n")
    nombre=input("Diligencie el nombre del producto: ").upper()
    marca=input("Diligencie la marca del producto: ").upper()
    f.ingresar_actualizar_producto(nombre,marca)

  elif opcion=='2':
        print("\n")
        print("Resultado Inventario")
        f.imprimir_inventario()

  elif opcion=='3':
        print("\n")
        print("Resultado Inventario categoria")
        f.imprimir_inventario_categoria() 
  elif opcion=='4':
        print("\n")
        print("Facturar Venta")
        #codigo=int(input("Diligencie el codigo del producto: "))
        #f.fecha_actual()
        ventas=f. identificar_ventas()
        print(ventas)
        #f.facturar_venta()
  elif opcion=='5':
        print("\n")
        print("REGISTRO DE VENTAS")
        ventas=f. registrar_ventas()
        
  elif opcion=='6':
        print("\n")
        print("REPRESENTACIÓN GRÁFICA")
        ventas=f. graficar_ventas()
                                
  elif opcion=='0':
    print("Regresa pronto")
    break    
  else:
      print('Opción no válida')

