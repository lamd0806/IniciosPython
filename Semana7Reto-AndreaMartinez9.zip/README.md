# a.	Identificar el problema:
* Cuál es el problema

El dueño de un supermercado llevaba el control del inventario de manera manual en un cuaderno, a la fecha se ha sistematizado el ingreso de productos, la visualizacion del inventario y la generación de facturas. Ahora se requiere un módulo informativo, en el cual se pueda evidenciar la cantidad de productos vendidos en el mes y su información relacionada.

* Quienes son los interesados

Dueño Supermercado--cliente

Hijo dueños supermercado--Usuarios

* Cuál es el objetivo?

Sistematizar el acceso de la información en un software

* Se tienen restricciones?

No

# b.	Definir el problema:
* Que información conozco?

a. Debo tener un inventario.

b. El sistema debe permitir ingresar información consolidada de las ventas, relacionando los siguientes datos: producto, marca, ventas, presentación y precio.

c. Con base a nuestra estructura de inventarios, obtener el valor de existencias y restarle las ventas para obtener el número de productos en stock que también se
debe relacionar en el cuadro informativo

d. La información se debe presentar por medio de una matriz , debo utilizar la librería Pandas para crear el tablero de informes 

e. Se debe representar en un gráfico las ventas asociadas al producto, usar la librería matplotlib para generar el gráfico de ventas.

f.los datos para generar el grafico deben ser ingresados por consola por medio de inputs.
 
# c.Estrategias:

* Pruebas de escritorio
* Validar si el producto existe en la lista antes de tomar decisiones (buscar por codigo)
* Si existe debo actualizar mis existencias de acuerdo a la cantidad de unidades a ser vendidas.
* Si es una venta las existencias del producto van a disminuir
* Actualizar productos
* Consultar como sumar existencias nuevas a las actuales y como restar en caso de que sea una venta
* Validar la funcionalidad de pandas y matplotlib


# d.	Algoritmos:

menus de opciones

funciones

Invocar funciones

Imprimir resultados

# e. Logros:

1.	Implementar la aplicación en Python 
---------------------------------------------------
a. Definiendo funciones con parámetros 

Se crean 2 funciones una para registrar las ventas y otra para graficar, se accede a través de las opciones del menú:

  ('5. Registrar Venta')
  ('6. Graficar Ventas')

b. Invocando funciones correctamente 

* Se cuenta con una función general para analizar si se crea o si se actualizan los productos:

def ingresar_actualizar_producto(nombre,marca):

* Se crean 2 funciones para registrar y graficar las venats en el inventario:

def registrar_ventas()

graficar_ventas()

c. Documentando el código 
Los comentarios van después del # (numeral)

e.	Probando la aplicación: Se ingresa una lista de diccionarios inicial y se imprime según corresponda, se agregan productos nuevos a cada lista y se actualizan los existentes.Espacio para subir el metodo IDEAL