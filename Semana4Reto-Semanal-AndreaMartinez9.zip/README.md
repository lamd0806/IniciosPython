# a.	Identificar el problema:
* Cuál es el problema

El dueño lleva el control del inventario de manera manual en un cuaderno

* Quienes son los interesados

Dueño Supermercadocliente
Hijo dueños supermercadoUsuarios

* Cuál es el objetivo?

Sistematizar el acceso de la información en un software

* Se tienen restricciones?

No

# b.	Definir el problema:
* Que información conozco?

a. Cada semana llegan los proveedores de diferentes productos, para lo cual se requiere organizar el inventario en los siguientes grupos o listas: lácteos, aseo y granos.
 
b. Cada grupo o lista de productos debe estar relacionado a una nueva lista en donde se almacenará la cantidad de existencia en inventario, asociado por medio del índice.
Ejemplo: 
En donde Leche Colanta tiene 12 productos en existencia y Leche Alpina tiene 14 productos en existencia. 

c. El sistema debe permitir ingresar el nombre del producto y el número de los mismos, además de la categoría a la que pertenecen. (1)

d. Debe validar que, si el producto no existe en la lista, lo debe agregar al final, al igual que el número en la lista de existencias. Si ya existe, debe buscar el valor asociado al índice y sumarle el número de productos a las existencias correspondientes. 

e. Finalmente imprimir cada producto con sus respectivas existencias en inventario.

Que información debo conocer
Puede haber varias marcas de un producto.
Espacio para subir laboratorios

# c.Estrategias:

* Pruebas de escritorio
* Validar si el producto existe en la lista antes de tomar decisiones
* Agregar productos
* Actualizar productos
* Consultar como sumar existencias nuevas a las actuales
* identificar el indice del campo a Actualizar
* imprimir resultados
* imprimir inventario general

# d.	Algoritmos:

menus de opciones

funciones

Invocar funciones

Imprimir resultados

# e. Logros:

1.	Implementar la aplicación en Python 

a. Definiendo funciones con parámetros 

Se crean 3 funciones para imprimir el inventario de cada grupo de listas

Se crea una función general para analizar si se crea o si se actualizan los productos

b. Invocando funciones correctamente 

* Se crea una función general para analizar si se crea o si se actualizan los productos:

ingresar_actualizar_producto(grupo,nombre,existencias)

* Se crean 3 funciones para imprimir el inventario de cada grupo de listas:

imprimir_lacteos()

imprimir_grano()

imprimir_aseo()


c. Documentando el código 
Los comentarios van después del # (numeral)

e.	Probando la aplicación: Se ingresa una lista inicial y se imprime , se agregan productos nuevos a cada lista y se actualizan los existentes.




