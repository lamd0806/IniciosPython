
import funciones as f


#MENU GENERAL
"""
Creado por: Luz Andrea Martínez Díaz
Fecha: 28/05/2021
"""
# Opciones Generales
while True:
    print("\n")
    print('INVENTARIO')    
    print('1. Ingresar o actualizar Producto')
    print('2. Imprimir Inventario')
    print('0. Salir del Programa')
    print("\n")
    
    opcion=input('Seleccione una opción: ')
    if opcion=='1':
      print("\n")
      grupo=input("Ingrese el grupo\n 1.Lacteos \n 2.Aseo \n 3.Granos \n")
      nombre=input("Diligencie el nombre del producto: ").upper()
      #existencias=[]
      existencias=int((input("Ingrese la cantidad de existencias: ")))
      #existencias.append(cantidad_existencia)
      f.ingresar_actualizar_producto(grupo,nombre,existencias)
    elif opcion=='2':
        print("\n")
        print("Resultado Inventario")
        f.imprimir_lacteos()
        f.imprimir_grano()
        f.imprimir_aseo()
    elif opcion=='0':
        break    
    else:
          print('Opción no válida')

