##DEFINIR LISTAS Y ALGUNA INFORMACION
lacteos=["LECHE COLANTA"]
existencia_lacteos=[2]

aseo=["JABON DE BAÑO PALMOLIVE"]
existencia_aseo=[5]

grano=["LENTEJA ABURRA"]
existencia_grano=[15]


#INGRESAR O ACTUALIZAR PRODUCTO (LACTEOS,ASEO,GRANO)
def ingresar_actualizar_producto(grupo,nombre,existencias):
    
  if grupo=="1":
    print("INVENTARIO LACTEOS")
    if nombre in lacteos:
      print("¡El producto ya existe!")
      ubicacion_elemento=lacteos.index(nombre)
      Total=int(existencia_lacteos[ubicacion_elemento])+existencias
      existencia_lacteos.insert(ubicacion_elemento,Total)
      resultado=print(nombre, "Ya existe, se actualizan las existencias")
      print(lacteos[ubicacion_elemento],"tiene",existencia_lacteos[ubicacion_elemento], "en Inventario")
      return resultado
    else:
      lacteos.append(nombre)
      existencia_lacteos.append(existencias)
      resultado=print(nombre,"con",existencias," existencias se agrega a la lista")
      return resultado
  elif grupo=="2":
    print("INVENTARIO ASEO")
    if nombre in aseo:
      print("¡El producto ya existe!")
      ubicacion_elemento=aseo.index(nombre)
      Total=int(existencia_aseo[ubicacion_elemento])+existencias
      existencia_aseo.insert(ubicacion_elemento,Total)
      resultado=print(nombre, "Ya existe, se actualizan las existencias")
      print(aseo[ubicacion_elemento],"tiene",existencia_aseo[ubicacion_elemento], "en Inventario")
      return resultado
    else:
      aseo.append(nombre)
      existencia_aseo.append(existencias)
      resultado=print(nombre,"con",existencias,"existencias se agrega a la lista")
      return resultado
  elif grupo=="3":
    print("INVENTARIO GRANO")
    if nombre in grano:
      print("¡El producto ya existe!")
      ubicacion_elemento=grano.index(nombre)
      Total=int(existencia_grano[ubicacion_elemento])+existencias
      existencia_grano.insert(ubicacion_elemento,Total)
      resultado=print(nombre, "Ya existe, se actualizan las existencias")
      print(grano[ubicacion_elemento],"tiene",existencia_grano[ubicacion_elemento], "en Inventario")
      return resultado
    else:
      grano.append(nombre)
      existencia_grano.append(existencias)
      resultado=print(nombre,"con",existencias,"existencias se agrega a la lista")
      return resultado
  else:
    print('Opción no válida')




##IMPRIMIR INVENTARIO DE CADA PRODUCTO

def imprimir_lacteos():
  print("\n")
  print("LACTEOS")
  contador=0
  tamaño_lista=len(lacteos)
  while contador < tamaño_lista:
    print("Producto",lacteos[contador],"tiene en existencia",existencia_lacteos[contador])
    contador=contador+1

def imprimir_aseo():
  print("\n")
  print("ASEO")
  contador=0
  tamaño_lista=len(aseo)
  while contador < tamaño_lista:
    print("Producto",aseo[contador],"tiene en existencia",existencia_aseo[contador])
    contador=contador+1

def imprimir_grano():
  print("\n")
  print("GRANO")
  contador=0
  tamaño_lista=len(grano)
  while contador < tamaño_lista:
    print("Producto",grano[contador],"tiene en existencia",existencia_grano[contador])
    contador=contador+1    

 