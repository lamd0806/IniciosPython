#Espacio para Lectura variables de entrada
lpm = float(input("Digite el valor del largo de la puerta en metros: "))
lm=float(input("Digite el valor del largo del muro en metros: "))
d= float(input("Digite el valor del diametro de la polea en centimetros: "))
minutos = float(input("Digite el valor de minutos maximos para cerrar la puerta: "))

#Espacio para definir funciones

# Calcular perimetro de la polea
def calcular_perimetro_polea(d):
  #d= diametro polea , pc=perimetro polea
  pc=(2*3.14)*(d/2)
  return pc

# Calcular longitud de hipotenusa
def calcular_hipotenusa_lado_cuerda(lpm,lm):
  #lpm=largo puerta en metros, lm= largo muro en metros,hcm= hipotenusa en centimetros
  h=((lpm**2)+(lm**2))*0.5
  hcm=h*100
  return hcm

#Calcular cantidad de vueltas para girar la polea hasta cerrar la puerta
def calcular_vueltas_cerrar(lpm,d,lm):
# lpm=largo puerta en metros, lm= largo muro en metros,d= diametro polea, lh= longitud hipotenusa p=calculo perimetro polea, lce=longitudcuerdaenrrollada
  lh=calcular_hipotenusa_lado_cuerda(lpm,lm)
  p=calcular_perimetro_polea(d)
  lce=lh-((lm-lpm)*100)
  vueltas= lce/p
  return  vueltas

#Calcular cantidad de chewbaccas para cerrar puerta
def calcular_chewbacca_cerrar(lpm,d,lm):
  #lpm=largo puerta en metros, lm= largo muro en metros,d=diametro polea en centimetros
  v= calcular_vueltas_cerrar(lpm,d,lm)
  vueltas_Chewbacca =v/3
  return  vueltas_Chewbacca


#Calcular velocidad giro para cerrar puerta en cierto tiempo
def velocidad_giro_tiempo(minutos,lpm,lm):
  lh=calcular_hipotenusa_lado_cuerda(lpm,lm)
  min_seg=minutos*60
  lce=lh-((lm-lpm)*100)
  velocidad= lce/min_seg
  return velocidad


#Espacio para invocar funciones
pp=calcular_perimetro_polea(d)
print ("Perimetro de la polea es",pp)

hip=calcular_hipotenusa_lado_cuerda(lpm,lm)
print ("largo hipotenusa: ",hip)

vueltas_cerrar=calcular_vueltas_cerrar(lpm,d,lm)
print("la cantidad de vueltas para cerrar la puerta es: ",vueltas_cerrar)

chewbacca_cerrar=calcular_chewbacca_cerrar(lpm,d,lm)
print("la cantidad de chewbaccas para cerrar la puerta es: ",chewbacca_cerrar)

cerrar_puerta_cms=velocidad_giro_tiempo(minutos,lpm,lm)
print("la velocidad para cerrar la puerta es: ",cerrar_puerta_cms)

