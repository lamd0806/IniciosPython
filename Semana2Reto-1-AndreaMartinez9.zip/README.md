# Que debes hacer?
1.	Aplicar el proceso IDEAL completamente, es decir:

## a.	Identificar el problema:
Cuál es el problema:

Sólo se puede cerrar bajo ataque, el problema es que se demoran mucho para cerrarla en ocasiones no alcanzan a cerrarla completamente y el castillo es saqueado.

Quienes son los interesados

Rey Arturito-->cliente

Chewbaccas-->Usuarios

Cuál es el objetivo?

Conocer con cuantas vueltas y con cuantos Chewbaccas se pueda cerrar la puerta en un tiempo establecido.

Se tienen restricciones?

No

## b.	Definir el problema:
Que información conozco?

-El largo de la puerta en metros

-Asumir altura muro

-El diámetro de la polea en centímetros

-Minutos máximos para cerrar la puerta

-Un Chewbacca sólo puede girar la polea 3 veces antes de caer exhausto

Que información debo conocer

-las fórmulas para calcular:

el perímetro del circulo : pc=(2*3,14)*(d/2)

el cálculo del radio: r=d/2

largo de la puerta de metros a centímetros:

puerta_cm= largo * 100

calcular la velocidad :lce/tiempo

## c.	Estrategias:
Calcular la longitud de un lado de la cuerda.

Calcular el perímetro del círculo 

Calcular con cuantas vueltas se cerraría la puerta

Calcular con cuantos Chewbaccas se puede cerrar una puerta

Calcular a qué velocidad debo girar mi polea basada en un tiempo

Retornar la respuesta al rey Arturito y los caballeros de la mesa para los interrogantes:

¿Cuántas vueltas deben darse para cerrar la puerta completamente? 

¿Cuántos Chewbaccas se necesitan para cerrar la puerta?

¿A qué velocidad deben girar la polea (cms/seg) para poder cerrar la puerta en un tiempo?

## d.	Algoritmos:

Leer largo puerta mt

Leer diametro polea cm

Leer minutos cerrar puerta


Calcular perímetro de la polea

Calcular longitud de hipotenusa

Calcular cantidad de vueltas para girar la polea hasta cerrar la puerta

Calcular cantidad de chewbaccas para cerrar puerta

Calcular velocidad de giro para cerrar la puerta en determinado tiempo

Invocar funciones

Imprimir resultados

 e. Logros:

# 2.	Implementar la aplicación en Python 

## a. Definiendo funciones con parámetros 
#Calcular perimetro de la polea
def calcular_perimetro_polea(d):
  pc=(2*3.14)*(d/2)
  return pc

#Calcular longitud de un lado de la cuerda (Duda)
def calcular_hipotenusa_lado_cuerda(lpm):
#lpm=largo puerta en metros
#cm= largo puerta en centimetros
cm=lpm*100
h=2*(cm**2)*0.5
return h

#Calcular cantidad de vueltas para girar la polea hasta cerrar la puerta
def calcular_vueltas_cerrar(lpm,d):

  lh=calcular_hipotenusa_lado_cuerda(lpm)
  p=calcular_perimetro_polea(d)
  vueltas= lh/p
  return  vueltas

#Calcular cantidad de chewbaccas para cerrar puerta
def calcular_chewbacca_cerrar(lpm,d):
  v= calcular_vueltas_cerrar(lpm,d)
  vueltas_Chewbacca =v/3
  return  vueltas_Chewbacca

""""
#Calcular velocidad giro para cerrar puerta en cierto tiempo"""
"""Def velocidad_giro_tiempo()

Return velocidad"""


## b. Invocando funciones correctamente 
#Espacio para invocar funciones
pp=calcular_perimetro_polea(d)
print ("Perimetro de la polea es",pp)

hip=calcular_hipotenusa_lado_cuerda(lpm)
print ("largo hipotenusa: ",hip)

vueltas_cerrar=calcular_vueltas_cerrar(lpm,d)
print("la cantidad de vueltas para cerrar la puerta es: ",vueltas_cerrar)

chewbacca_cerrar=calcular_chewbacca_cerrar(lpm,d)
print("la cantidad de chewbaccas para cerrar la puerta es: ",chewbacca_cerrar)

## c. Documentando el código 
Los comentarios van después del # (numeral)

## e.	Probando la aplicación 

Digite el valor del largo de la puerta en metros:2
Digite el valor del diametro de la polea en centimetros:1000
Digite el valor de minutos maximos para cerrar la puerta:4
Perimetro de la polea es 3140.0
largo hipotenusa:  40000.0
la cantidad de vueltas para cerrar la puerta es:  12.738853503184714
la cantidad de chewbaccas para cerrar la puerta es:  4.246284501061571

 




