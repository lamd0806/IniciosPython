# a.	Identificar el problema:
* Cuál es el problema

El dueño de un supermercado llevaba el control del inventario de manera manual en un cuaderno, a la fecha se ha sistematizado el ingreso de productos y la visualizacion del inventario. Ahora se requiere Implementar la generacion de facturas 

* Quienes son los interesados

Dueño Supermercadocliente
Hijo dueños supermercadoUsuarios

* Cuál es el objetivo?

Sistematizar el acceso de la información en un software

* Se tienen restricciones?

No

# b.	Definir el problema:
* Que información conozco?

a. Tengo un inventario.

b. la busqueda de producto se realizará por el id del producto, de allí obtendré el precio del producto y lo asociaré a la venta.

c. El ingreso de los productos a vender se deben registar luego de solicitada una acción, si la acción a ingresar es diferente de "R" sólo se facturaran dichos productos.

d.Se debe generar un archivo (factura) que contenga:

 El nombre del supermercado

 El Nit 

 Los productos que se van a vender con su precio

 El precio total (la suma de todo los productos a vender) sin IVA
 
El precio total con IVA del 19%

e. El archivo debe tener por nombre:
"Nombre de Supermercado fecha del sistema y hora"

# c.Estrategias:

* Pruebas de escritorio
* Validar si el producto existe en la lista antes de tomar decisiones
* Si existe debo recorrer los key y obtener el precio, la cantidad y el nombre del producto y escribirlos en mi factura la cantidad de veces que quiera el cliente. El total se guardara en un acumulador si termina el ciclo , se escribe en el archivo el total y el total con IVA
* Agregar productos
* Si es una venta las existencias del producto van a disminuir
* Actualizar productos
* Consultar como sumar existencias nuevas a las actuales
* imprimir resultados por categoria
* imprimir inventario general

# d.	Algoritmos:

menus de opciones

funciones

Invocar funciones

Imprimir resultados

# e. Logros:

1.	Implementar la aplicación en Python 
---------------------------------------------------
a. Definiendo funciones con parámetros 

Se crean 3 funciones una para actualizar o ingresar productos, otra para imprimir el inventario general y otra para imprimir el inventario por categoria

b. Invocando funciones correctamente 

* Se crea una función general para analizar si se crea o si se actualizan los productos:

def ingresar_actualizar_producto(nombre,marca):

* Se crean 2 funciones para imprimir el inventario:

def imprimir_inventario():

def imprimir_inventario_categoria():


c. Documentando el código 
Los comentarios van después del # (numeral)

e.	Probando la aplicación: Se ingresa una lista de diccionarios inicial y se imprime según corresponda, se agregan productos nuevos a cada lista y se actualizan los existentes.