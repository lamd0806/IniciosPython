"""
Reto Semana 6
Nombre:Luz Andrea Martínez Díaz
Fecha:09/06/2021
"""
from datetime import datetime
import pytz



##DEFINIR LISTAS Y ALGUNA INFORMACION
inventario=[{
    "id" : 1245,#key:value
    "nombre": "LOMO DE CERDO",
    "marca": "CARNES DEL CAMPO",
    "categoria": "carnicos",
    "fecha_ingreso": "31/05/2021",
    "fecha_vencimiento":"31/07/2021",
    "precio":12500,
    "presentacion":"Kilo",
    "existencia":12
    },{
    "id" : 1246,#key:value
    "nombre": "COSTILLA DE CERDO",
    "marca": "CARNES DEL CAMPO",
    "categoria": "carnicos",
    "fecha_ingreso": "31/05/2021",
    "fecha_vencimiento":"14/06/2021",
    "precio":11500,
    "presentacion":"Kilo",
    "existencia":10},
    {
    "id" : 1247,#key:value
    "nombre": "PESCADO",
    "marca": "BUENA MAR",
    "categoria": "carnicos",
    "fecha_ingreso": "31/06/2021",
    "fecha_vencimiento":"14/07/2021",
    "precio":15000,
    "presentacion":"libra",
    "existencia":20}]

inv={}
fact={}

facturar=[{
    "id" : 0,#key:value
    "nombre": "Base",
    "precio":0    
    }]

#INGRESAR O ACTUALIZAR PRODUCTO
def ingresar_actualizar_producto(nombre,marca):
  for producto in inventario:
    for key in producto:
      
      if producto["nombre"]==nombre and producto["marca"]==marca:

       print("El producto ya existe")
       print("Sin actualizar",producto["existencia"])
       existencias=int(input("Ingrese la cantidad de existencias a agregar: "))

       producto["existencia"]= producto["existencia"] + existencias

       print("Actualizado",producto["existencia"])
       return inventario
      else:None
                
     
  print("Debe ingresar el producto")
  id=int(input("Ingrese el id: "))
  nombre=input("Diligencie el nombre del producto: ").upper()
  marca=input("Diligencie la marca del producto: ").upper()
  categoria=input("Diligencie la categoria: ")
  fecha_ingreso=input("Diligencie la fecha ingreso: ")
  fecha_vencimiento=input("Diligencie la fecha vencimiento: ")
  precio=int(input("Ingrese el precio: "))
  presentacion=input("Diligencie tipo presentación: ")
  existencias=int(input("Ingrese la cantidad de existencias: "))
  inv["id"]=id
  inv["nombre"]=nombre
  inv["marca"]=marca
  inv["categoria"]=categoria
  inv["fecha_ingreso"]=fecha_ingreso
  inv["fecha_vencimiento"]=fecha_vencimiento
  inv["precio"]=precio
  inv["presentacion"]=presentacion
  inv["existencias"]=existencias
  inventario.append(inv)
  print("Producto agregado")
        
#Funcion para imprimir inventario general
def imprimir_inventario():
  for producto in inventario:
    print(producto,"\n")     
  print("-----------------")
  
#Funcion para imprimir inventario por categoria  
def imprimir_inventario_categoria():
  categoria=input("Diligencia la categoria:")
  for inv in inventario:
    for key in inv:
      if(inv[key]==categoria):
       print(inv,"\n")
    print("-----------------")
 
##Funcion que captura la fecha del sistema, genera un archivo y escribe en el nombre de supermercado y Nit 
def fecha_actual():
  tz = pytz.timezone('America/Bogota')
  x = datetime.now(tz) 
  x = x.strftime("%Y-%m-%d %H:%M:%S")
  return x

fecha = fecha_actual()
f = open("facturas/SupermercadoDonPepe"+fecha+".txt", "w")
f.write("Supermercado don Pepe \n")
f.write("Nit: 124545454 \n")
f.close()

def identificar_ventas():
  acumular_venta=0
  accion="r"
  while accion=="r":
    if accion =="r":
      codigo=int(input("Diligencie el codigo del producto: "))
      for producto in inventario:
        try:
          if codigo==producto["id"]:
            print("El producto se agregará a la factura")
            codigo=int(producto["id"])
            nombre=producto["nombre"]
            precio=int(producto["precio"])

            f = open("facturas/SupermercadoDonPepe"+fecha+".txt", "a")
            f.write(nombre + "-")
            f.write("CODIGO "+ str(codigo) + "-")
            f.write("PRECIO "+ str(precio)+ "\n")
            acumular_venta+=precio
        except:
          print("El producto no está en el inventario, Seleccione la opción '1' del Menú")
                
    accion=input("Ingrese la opción 'r' para REGISTRAR o cualquier letra para regresar al MENÚ: ")

  f.write("Precio de la Venta sin IVA: " + str(acumular_venta) + "\n")
  venta_iva=acumular_venta*1.19
  f.write("Precio de la Venta con IVA del 19%: " + str(venta_iva) + "\n")
  f.close()
  