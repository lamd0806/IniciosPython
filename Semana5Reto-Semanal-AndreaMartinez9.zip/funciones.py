##DEFINIR LISTAS Y ALGUNA INFORMACION
inventario=[{
    "id" : 1245,#key:value
    "nombre": "LOMO DE CERDO",
    "marca": "CARNES DEL CAMPO",
    "categoria": "carnicos",
    "fecha_ingreso": "31/05/2021",
    "fecha_vencimiento":"31/07/2021",
    "precio":12500,
    "presentacion":"Kilo",
    "existencia":12
    },{
    "id" : 1246,#key:value
    "nombre": "COSTILLA DE CERDO",
    "marca": "CARNES DEL CAMPO",
    "categoria": "carnicos",
    "fecha_ingreso": "31/05/2021",
    "fecha_vencimiento":"14/06/2021",
    "precio":11500,
    "presentacion":"Kilo",
    "existencia":10}]

inv={}


#INGRESAR O ACTUALIZAR PRODUCTO
def ingresar_actualizar_producto(nombre,marca):
  for producto in inventario:
    for key in producto:
      
      if producto["nombre"]==nombre and producto["marca"]==marca:

       print("El producto ya existe")
       print("Sin actualizar",producto["existencia"])
       existencias=int(input("Ingrese la cantidad de existencias a agregar: "))

       producto["existencia"]= producto["existencia"] + existencias

       print("Actualizado",producto["existencia"])
       return inventario
      else:None
                
     
  print("Debe ingresar el producto")
  id=int(input("Ingrese el id: "))
  nombre=input("Diligencie el nombre del producto: ").upper()
  marca=input("Diligencie la marca del producto: ").upper()
  categoria=input("Diligencie la categoria: ")
  fecha_ingreso=input("Diligencie la fecha ingreso: ")
  fecha_vencimiento=input("Diligencie la fecha vencimiento: ")
  precio=int(input("Ingrese el precio: "))
  presentacion=input("Diligencie tipo presentación: ")
  existencias=int(input("Ingrese la cantidad de existencias: "))
  inv["id"]=id
  inv["nombre"]=nombre
  inv["marca"]=marca
  inv["categoria"]=categoria
  inv["fecha_ingreso"]=fecha_ingreso
  inv["fecha_vencimiento"]=fecha_vencimiento
  inv["precio"]=precio
  inv["presentacion"]=presentacion
  inv["existencias"]=existencias
  inventario.append(inv)
  print("Producto agregado")
        
#Funcion para imprimir inventario general
def imprimir_inventario():
  for producto in inventario:
    print(producto,"\n")     
  print("-----------------")
  
#Funcion para imprimir inventario por categoria  
def imprimir_inventario_categoria():
  categoria=input("Diligencia la categoria:")
  for inv in inventario:
    for key in inv:
      if(inv[key]==categoria):
       print(inv,"\n")
    print("-----------------")
 
  
 