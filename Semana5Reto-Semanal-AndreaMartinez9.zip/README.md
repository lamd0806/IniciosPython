# a.	Identificar el problema:
* Cuál es el problema

El dueño lleva el control del inventario de manera manual en un cuaderno

* Quienes son los interesados

Dueño Supermercadocliente
Hijo dueños supermercadoUsuarios

* Cuál es el objetivo?

Sistematizar el acceso de la información en un software

* Se tienen restricciones?

No

# b.	Definir el problema:
* Que información conozco?

a. Requiere categorizar los productos en grupos (lácteos, aseo, cárnicos, granos, dulces, fruver, licores, entre otros)
 
b. Requiere almacenar además del nombre, categoría y existencias que ya estábamos gestionando; la fecha de ingreso al inventario, la fecha de vencimiento
del producto, precio, marca, identificador único y presentación

c. Imprimir cada producto con sus respectivas existencias en inventario

d. Debe validar que, si el producto no existe en la lista, lo debe agregar al final, al igual que el número en la lista de existencias. Si ya existe, debe buscar el valor asociado al índice y sumarle el número de productos a las existencias correspondientes. 

e. Imprimir cada producto con sus respectivas existencias en inventario

Que información debo conocer
Puede haber varias marcas de un producto,validar por producto y marca.

# c.Estrategias:

* Pruebas de escritorio
* Validar si el producto existe en la lista antes de tomar decisiones
* Agregar productos
* Actualizar productos
* Consultar como sumar existencias nuevas a las actuales
* imprimir resultados por categoria
* imprimir inventario general

# d.	Algoritmos:

menus de opciones

funciones

Invocar funciones

Imprimir resultados

# e. Logros:

1.	Implementar la aplicación en Python 
---------------------------------------------------
a. Definiendo funciones con parámetros 

Se crean 3 funciones una para actualizar o ingresar productos, otra para imprimir el inventario general y otra para imprimir el inventario por categoria

b. Invocando funciones correctamente 

* Se crea una función general para analizar si se crea o si se actualizan los productos:

def ingresar_actualizar_producto(nombre,marca):

* Se crean 2 funciones para imprimir el inventario:

def imprimir_inventario():

def imprimir_inventario_categoria():


c. Documentando el código 
Los comentarios van después del # (numeral)

e.	Probando la aplicación: Se ingresa una lista de diccionarios inicial y se imprime según corresponda, se agregan productos nuevos a cada lista y se actualizan los existentes.