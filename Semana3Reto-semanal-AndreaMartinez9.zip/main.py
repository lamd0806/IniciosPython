#---------------- Zona librerias------------
#import calculos as cal
import calculo as c
#Invocar funciones

op=c.menu_operaciones()

if op=="1":
  print("Ingrese cantidad de Vacas")
  vacas=int(input("Ingrese la cantidad de vacas: "))
  valor_venta=c.calcular_Valor_Venta(vacas)
  print ("Total=",valor_venta)
elif op=="2":
  print("Ingrese cantidad de Mantequilla y Queso en KG")
  kg_mantequilla=float(input("Ingrese la cantidad de Mantequilla en KG: "))
  kg_queso=float(input("Ingrese la cantidad de Queso en KG: "))
  vacas=c.calcular_vacas(kg_mantequilla,kg_queso)
  print (vacas)
elif op=="3":
  print("Ingrese precios Mantequilla y Queso")
  precio_mantequilla=float(input("Ingrese precio Mantequilla: "))
  precio_queso=float(input("Ingrese precio Queso: "))
  vacas=int(input("Ingrese la cantidad de vacas: "))
  valor_venta_pmantequilla_pqueso=c.calcular_venta_parametrica(precio_mantequilla,precio_queso,vacas)
  print (valor_venta_pmantequilla_pqueso)  
else:
  print("Opción no valida")  
