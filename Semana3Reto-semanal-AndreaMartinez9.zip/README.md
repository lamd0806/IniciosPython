# Que debes hacer?
# 1.	Aplicar el proceso IDEAL completamente, es decir:

a.	Identificar el problema:
Cuál es el problema

Reto Un granjero tiene 3 vacas que producen en promedio 24 litros de leche diarios, con el 75% de la leche produce 12 kilogramos de mantequilla y con el 25% restante produce 4 kilogramos de queso, 1 kilogramo de mantequilla se vende en 6.500 pesos y 1 kilogramo de queso en 7.200 pesos. 
El granjero consigue un contrato para proveer queso y mantequilla a un reconocido supermercado de la ciudad, llegando al siguiente acuerdo: A partir de los 50 kg, tanto de queso como de mantequilla debe aplicar un descuento del 8%, y a partir de los 100 kg un descuento del 12%, además si el valor de la venta supera los 500 mil aplica un descuento adicional del 3%. 


Quienes son los interesados
Granjerocliente,usuario

Cuál es el objetivo?
El granjero necesita identificar cuantas vacas necesita de acuerdo a la producción de leche para mantequilla y queso  que se requiera a la semana, a su vez, requiere identificar el valor total de venta de sus productos sin/con los descuentos que pacto con el supermercado.

a)	Diseñe un algoritmo que permita calcular el valor de la venta ingresando el número de vacas. 

b)	Diseñe un algoritmo que permita calcular el número de vacas que necesita, ingresando la cantidad de kilos de queso y mantequilla que requiere vender. 

c)	Diseñe un algoritmo que permita calcular el valor de la venta, ingresando el precio del kilo de queso y mantequilla como parámetro.


Se tienen restricciones?
No


b.	Definir el problema:
Que información conozco?

- 3 vacas que producen en promedio 24 litros de leche diarios, con el 75% de la leche produce 12 kilogramos de mantequilla y con el 25% restante produce 4 kilogramos de queso.

- 1 vaca produce en promedio 8 litros de leche diario, con 6 lts produce 4kg de mantequilla y con 2 lts produce 1.33 kg de queso

- Precio de venta 1kg  mantequilla : 6.500 pesos 
 
- precio de venta  1 kg  de queso:  7.200 pesos. 

Las ventas se hacen semanalmente

Que información debo conocer
-las fórmulas para calcular:
Valor de venta de acuerdo a las vacas

Cantidad de vacas de acuerdo a la cantidad de kg de mantequilla y queso

Valor de venta ingresando precio kilo mantequilla y queso por parámetros

c.	Estrategias:

Calcular los kilogramos de mantequilla y queso por vaca

Calcular las vacas de acuerdo a los kilogramos de mantequilla y queso ingresados

Calcular el Valor Neto al ingresar el precio kg mantequilla y queso (de acuerdo a los kg aplican descuentos)

Calcular el valor de venta de acuerdo a la cantidad de vacas ingresadas, el precio de la mantequilla y el queso en este caso es el mencionado en el ejercicio(de acuerdo a los kg aplican descuentos)

Calcular la cantidad de vacas de acuerdo a los kg de mantequilla y queso


d.	Algoritmos:


 e. Logros:

2.	Implementar la aplicación en Python 

a. Definiendo funciones con parámetros 
  
#----------Definición de Funciones (Dividir)------------
def menu_operaciones():
  print("==================================================")
  print("| Menu")
  print("==================================================")
  print("| Ingresa un número para realizar calculo.")
  print("==================================================")
  print("| 1. Calcular Valor Venta ingresando cantidad de vacas: (1)")
  print("==================================================")
  print("| 2. Calcular número de vacas ingresando cantidad kilogramos de mantequilla y queso: (2)")
  print("==================================================")
  print("| 3. Calcular Valor venta ingresando precio en kilogramos para mantequilla y queso: (3)")
  print("==================================================")
   
  opcion = input()
  return opcion

def totales_semanales(precio_mantequilla,precio_queso,vacas,kg_mantequilla,kg_queso):
  valor_venta_vacas=calcular_Valor_Venta(vacas)*7
  valor_venta_parametrico=calcular_venta_parametrica(precio_mantequilla,precio_queso,vacas)*7
  cantidad_vacas_kg=calcular_vacas(kg_mantequilla,kg_queso)*7
  return valor_venta_vacas,valor_venta_parametrico,cantidad_vacas_kg

#Se ingresa precio kg mantequilla y queso para obtener Valor Total con descuentos
def calcular_venta_parametrica(precio_mantequilla,precio_queso,vacas):
  #el precio sólo no me sirve necesito conocer la cantidad de kg por vaca invoco funcion creada para esto
  kg_mant,kg_que,kg_total=calcular_kg_vacas(vacas)
  precio_mant=kg_mant*precio_mantequilla
  precio_que=kg_que*precio_queso
  valor_venta=precio_mant+precio_que
    
  if (50<=kg_total<100) and valor_venta>=500000:
    print("Hay descuento por cantidad de kilos y valor superior a 500 mil")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-(0.08 + 0.03)
  elif 50<=kg_total<100 and valor_venta<500000:
    print("Hay descuento por cantidad de kilos")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-0.08
  elif kg_total>=100 and valor_venta>=500000:
    print("Hay descuento por cantidad de kilos (100) y valor superior a 500 mil")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-(0.12 + 0.03)
  elif kg_total>=100 and valor_venta<500000:
    print("Hay descuento por cantidad de kilos (100)")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-0.12
  else:
    print("No hay descuento")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    Total=("El total a pagar es: ",valor_venta)
  return Total

#Calcula cantidad de vacas de acuerdo a los kg de mantequilla y queso
def calcular_vacas(kg_mantequilla,kg_queso):
  litros_leche_una_vaca=8
  lts_leche=((kg_mantequilla*6)/4)+((kg_queso*2)/1.33)
  cantidad_vacas=lts_leche/litros_leche_una_vaca
  print("Para una producción de ",kg_mantequilla,"Kilos de mantequilla y ",kg_queso,"Kilos de Queso se necesitan",cantidad_vacas, "Vacas")
  return cantidad_vacas

#Calcula la cantidad de Kg de mantequilla y queso que se puede obtener de cierta cantidad de vacas
def calcular_kg_vacas(vacas):
  lts_leche=vacas*8
  porcentaje_mantequilla=lts_leche*0.75
  porcentaje_queso=lts_leche*0.25
  mantequilla_kg=(porcentaje_mantequilla*4)/6
  queso_kg=(porcentaje_queso*1.33)/2
  total_kg=mantequilla_kg+queso_kg
  return mantequilla_kg,queso_kg,total_kg

#calcula el valor de venta de acuerdo a la cantidad de vacas ingresadas, el precio de la mantequilla y el queso en este caso es el mencionado en el ejercicio
def calcular_Valor_Venta(vacas):
  kg_mant,kg_que,kg_total=calcular_kg_vacas(vacas)
  precio_mant=kg_mant*6500
  precio_que=kg_que*7200
  valor_venta=precio_mant+precio_que
    
  if (50<=kg_total<100) and valor_venta>=500000:
    print("Hay descuento por cantidad de kilos y valor superior a 500 mil")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-(0.08 + 0.03)
  elif 50<=kg_total<100 and valor_venta<500000:
    print("Hay descuento por cantidad de kilos")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-0.08
  elif kg_total>=100 and valor_venta>=500000:
    print("Hay descuento por cantidad de kilos (100) y valor superior a 500 mil")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-(0.12 + 0.03)
  elif kg_total>=100 and valor_venta<500000:
    print("Hay descuento por cantidad de kilos (100)")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-0.12
  else:
    print("No hay descuento")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    Total=("El total a pagar es: ",valor_venta)
  return Total




b. Invocando funciones correctamente 
#---------------- Zona librerias------------
#import calculos as cal
import calculo as c
#Invocar funciones

op=c.menu_operaciones()

if op=="1":
  print("Ingrese cantidad de Vacas")
  vacas=int(input("Ingrese la cantidad de vacas: "))
  valor_venta=c.calcular_Valor_Venta(vacas)
  print ("Total=",valor_venta)
elif op=="2":
  print("Ingrese cantidad de Mantequilla y Queso en KG")
  kg_mantequilla=float(input("Ingrese la cantidad de Mantequilla en KG: "))
  kg_queso=float(input("Ingrese la cantidad de Queso en KG: "))
  vacas=c.calcular_vacas(kg_mantequilla,kg_queso)
  print (vacas)
elif op=="3":
  print("Ingrese precios Mantequilla y Queso")
  precio_mantequilla=float(input("Ingrese precio Mantequilla: "))
  precio_queso=float(input("Ingrese precio Queso: "))
  vacas=int(input("Ingrese la cantidad de vacas: "))
  valor_venta_pmantequilla_pqueso=c.calcular_venta_parametrica(precio_mantequilla,precio_queso,vacas)
  print (valor_venta_pmantequilla_pqueso)  
else:
  print("Opción no valida")  



c. Documentando el código 
Los comentarios van después del # (numeral)

e.	Probando la aplicación 

 


