#----------Definición de Funciones (Dividir)------------
def menu_operaciones():
  print("==================================================")
  print("| Menu")
  print("==================================================")
  print("| Ingresa un número para realizar calculo.")
  print("==================================================")
  print("| 1. Calcular Valor Venta ingresando cantidad de vacas: (1)")
  print("==================================================")
  print("| 2. Calcular número de vacas ingresando cantidad kilogramos de mantequilla y queso: (2)")
  print("==================================================")
  print("| 3. Calcular Valor venta ingresando precio en kilogramos para mantequilla y queso: (3)")
  print("==================================================")
   
  opcion = input()
  return opcion

def totales_semanales(precio_mantequilla,precio_queso,vacas,kg_mantequilla,kg_queso):
  valor_venta_vacas=calcular_Valor_Venta(vacas)*7
  valor_venta_parametrico=calcular_venta_parametrica(precio_mantequilla,precio_queso,vacas)*7
  cantidad_vacas_kg=calcular_vacas(kg_mantequilla,kg_queso)*7
  return valor_venta_vacas,valor_venta_parametrico,cantidad_vacas_kg

#Se ingresa precio kg mantequilla y queso para obtener Valor Total con descuentos
def calcular_venta_parametrica(precio_mantequilla,precio_queso,vacas):
  #el precio sólo no me sirve necesito conocer la cantidad de kg por vaca invoco funcion creada para esto
  kg_mant,kg_que,kg_total=calcular_kg_vacas(vacas)
  precio_mant=kg_mant*precio_mantequilla
  precio_que=kg_que*precio_queso
  valor_venta=precio_mant+precio_que
  descuento_venta_1=valor_venta*0.08
  descuento_venta_2=valor_venta*0.12
  descuento_venta_3=valor_venta*0.03
    
  if (50<=kg_total<100) and valor_venta>500000:
    print("Hay descuento por cantidad de kilos y valor superior a 500 mil")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-(descuento_venta_1 + descuento_venta_3)
  elif 50<=kg_total<100 and valor_venta<=500000:
    print("Hay descuento por cantidad de kilos")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-descuento_venta_1
  elif kg_total>=100 and valor_venta>500000:
    print("Hay descuento por cantidad de kilos (100) y valor superior a 500 mil")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-(descuento_venta_2 + descuento_venta_3)
  elif kg_total>=100 and valor_venta<=500000:
    print("Hay descuento por cantidad de kilos (100)")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-descuento_venta_2
  else:
    print("No hay descuento")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    Total=("El total a pagar es: ",valor_venta)
  return Total

#Calcula cantidad de vacas de acuerdo a los kg de mantequilla y queso
def calcular_vacas(kg_mantequilla,kg_queso):
  litros_leche_una_vaca=8
  lts_leche=((kg_mantequilla*6)/4)+((kg_queso*2)/1.33)
  cantidad_vacas=lts_leche/litros_leche_una_vaca
  print("Para una producción de ",kg_mantequilla,"Kilos de mantequilla y ",kg_queso,"Kilos de Queso se necesitan",cantidad_vacas, "Vacas")
  return cantidad_vacas

#Calcula la cantidad de Kg de mantequilla y queso que se puede obtener de cierta cantidad de vacas
def calcular_kg_vacas(vacas):
  lts_leche=vacas*8
  porcentaje_mantequilla=lts_leche*0.75
  porcentaje_queso=lts_leche*0.25
  mantequilla_kg=(porcentaje_mantequilla*4)/6
  queso_kg=(porcentaje_queso*1.33)/2
  total_kg=mantequilla_kg+queso_kg
  return mantequilla_kg,queso_kg,total_kg

#calcula el valor de venta de acuerdo a la cantidad de vacas ingresadas, el precio de la mantequilla y el queso en este caso es el mencionado en el ejercicio
def calcular_Valor_Venta(vacas):
  kg_mant,kg_que,kg_total=calcular_kg_vacas(vacas)
  precio_mant=kg_mant*6500
  precio_que=kg_que*7200
  valor_venta=precio_mant+precio_que
  descuento_venta_1=valor_venta*0.08
  descuento_venta_2=valor_venta*0.12
  descuento_venta_3=valor_venta*0.03
    
  if (50<=kg_total<100) and valor_venta>500000:
    print("Hay descuento por cantidad de kilos y valor superior a 500 mil")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-(descuento_venta_1 + descuento_venta_3)
  elif 50<=kg_total<100 and valor_venta<=500000:
    print("Hay descuento por cantidad de kilos")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-descuento_venta_1
  elif kg_total>=100 and valor_venta>500000:
    print("Hay descuento por cantidad de kilos (100) y valor superior a 500 mil")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-(descuento_venta_2 + descuento_venta_3)
  elif kg_total>=100 and valor_venta<=500000:
    print("Hay descuento por cantidad de kilos (100)")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    print("Valor sin descuento",valor_venta)
    Total=valor_venta-descuento_venta_2
  else:
    print("No hay descuento")
    print("Kilogramos Mantequilla",kg_mant,"Kilogramos_queso",kg_que)
    Total=("El total a pagar es: ",valor_venta)
  return Total
